makePath = undefined;
main = function () {console.error('Hi, i\'m evil!')};